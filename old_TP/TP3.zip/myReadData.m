function tab = myReadData(filename)
    % ouverture du fichier
    fid = fopen(filename);
    
    % lecture du fichier. C : un cellarray
    C = textscan(fid, '%f %f %f %f','HeaderLines',1,'Delimiter',',');
    
    % fermeture du fichier
    fclose (fid);
    
    % transformation du cellarray en array simple
    tab = cell2mat(C);
end